function graficointegral() 
  subplot(1,2,1)
  grafico_superficie();
  subplot(1,2,2)
  grafico_franjas();
end

function grafico_superficie
  grafico_base()
  hold on
  f = @(x) 10+x.^2;
  % Sombreado
  x=linspace(2,10,100);
  y = f(x);
  xx = [x,10,2,2];
  yy = [y,0,0,f(2)];
  fill(xx,yy, [0.86, 0.86, 0.86]);
  % S
  text(6,22,'S','fontweight', 'bold', 'fontsize', 40);
  % Función
  plot(x,y, 'b', 'linewidth',4);
  axis off
  hold off  
end
function grafico_franjas
  grafico_base()
  hold on
  f = @(x) 10+x.^2;
  % Abscisas
  hold on
  for i = [2:10]
    plot([i,i],[0,f(i)],'k');
  end
  % Sombreado
  x = linspace(6,7,100);
  y = f(x);
  x = [x,7,6,6];
  y = [y,0,0,f(6)];
  fill(x,y, [0.86, 0.86, 0.86]);
  % Función
  x=linspace(2,10,100);
  y = f(x);
  plot(x,y, 'b', 'linewidth',5);
  axis off
  hold off  
end

function grafico_base
  f = @(x) 10+x.^2;
  hold on
  % Abscisas
  for i = [2,10]
    plot([i,i],[0,f(i)],'k');
  end
  % Ejes
  plot([-1,12],[0,0],'k','linewidth',2); 
  plot([1,1],[-1,130],'k','linewidth',2); 
  % Etiquetas
  text(11.5,7,'X','fontweight', 'bold', 'fontsize', 22);
  text(0.1,125,'Y','fontweight', 'bold', 'fontsize', 22);
  text(2, -8, 'a','fontweight', 'bold', 'fontsize', 18);
  text(10, -8, 'b','fontweight', 'bold', 'fontsize', 18);
  text(3,60,'y=f(x)','fontweight', 'bold', 'fontsize', 22);
end

