
clc
f = @(x) sin(x);

fprintf('Test para métodos de integración\n')
fprintf('--------------------------------\n')
fprintf('Se prueba la función sin(x) entre 0 y 3*pi/2\n');
fprintf('El valor exacto de la integral es 1.0\n');
fprintf('Se utilizan 1000 subintervalos\n\n');

a = 0.0;
b = 3*pi/2;
n = 1000;

fprintf('\nMétodo del rectángulo\n');
fprintf('---------------------\n');
tic 
s = integ_rectangulo(f, a, b, n);
error = abs(1.0-s)/1.0*100;
fprintf('s= %.15f  error= %.15f %%\n',s, error);
toc
fprintf('\nMétodo del trapecio\n');
fprintf('-------------------\n');
tic 
s = integ_trapecio(f, a, b, n);
error = abs(1.0-s)/1.0*100;
fprintf('s= %.15f  error= %.15f %%\n',s, error);
toc

fprintf('\nMétodo de la parábola\n');
fprintf('---------------------\n');
tic 
s = integ_parabola(f, a, b, n);
error = abs(1.0-s)/1.0*100;
fprintf('s= %.15f  error= %.15f %%\n',s, error);
toc


 