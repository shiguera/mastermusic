function fig_parabola()
  hold on
  
  % Función
  f = @(x) 3 + sin(x);
  a = pi/4;
  b = 5*pi/4;
  % Parábola por tres puntos: y = ax^2+bx+c
  P1 = [a, f(a)];
  xmed = a + (b-a)/2;
  P2 = [xmed, f(xmed)];
  P3 = [b, f(b)];
  A = [P1(1)^2 P1(1) 1; P2(1)^2 P2(1) 1; P3(1)^2 P3(1) 1];
  C = [f(P1(1)); f(P2(1)); f(P3(1))];
  abc = A\C;
  parab = @(x) abc(1)*x.^2 + abc(2)*x + abc(3);
  % Sombreado  
  % Hay que dibujar el sombreado lo primero para
  % que lo demás se dibuje encima y no quede tapado
  x = linspace(a,b,100);
  xx = [x,b,a];
  yy = [parab(x), 0, 0];
  fill(xx,yy,[0.86, 0.86, 0.86]);
  % Figura base
  figura_base()  
  % Punto medio
  plot(xmed,f(xmed), 'ob', 'markersize', 12, 'markerfacecolor', 'b');   
  % Parabola
  plot(x,parab(x), 'k'); 
  % Abscisa central
  plot([xmed, xmed], [0, f(xmed)], 'k');
  % Etiquetas
  text(xmed-0.2,-0.2,'Xmed', 'fontsize', 20, 'fontweight', 'bold');
  text(xmed-0.2, 1.6, 'Ymed', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  text(a-0.15, 1.6, 'Yizq', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  text(b+0.15, 1, 'Yder', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  
  hold off  
end

