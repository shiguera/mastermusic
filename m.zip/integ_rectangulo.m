 
 function S= integ_rectangulo(f,a,b,n)
  
   h = (b-a)/n;
  
   S=0;
   for i = 1:n
     xizq = a +(i-1)*h;
     xder = xizq + h;
     xmed = (xizq+xder)/2;
     ymed = f(xmed);
     area_subintervalo = ymed*h;
     S = S + area_subintervalo;
   end
  
  
 end

 
 