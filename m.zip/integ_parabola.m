 
 function S= integ_parabola(f,a,b,n)
  
   h = (b-a)/n;
  
   S=0;
   for i = 1:n
     xizq = a +(i-1)*h;
     xder = xizq + h;
     xmed = (xizq+xder)/2;
     yizq = f(xizq);
     yder = f(xder);
     ymed = f(xmed);
     area_subintervalo = (yizq + 4*ymed + yder)*h/6;
     S = S + area_subintervalo;
   end
  
  
 end

 
 