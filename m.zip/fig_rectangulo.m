function fig_rectangulo()
  hold on
  
  % Función
  f = @(x) 3 + sin(x);
  a = pi/4;
  b = 5*pi/4;
  xmed = a+(b-a)/2;
  ymed = f(xmed);
  % Sombreado  
  % Hay que dibujar el sombreado lo primero para
  % que lo demás se dibuje encima y no quede tapado
  x = [a,b,b,a];
  y = [ymed,ymed,0,0];
  fill(x,y,[0.86, 0.86, 0.86]);
  % Figura base
  figura_base()
  % Punto medio
  plot(xmed,ymed, 'ob', 'markersize', 12, 'markerfacecolor', 'b');   
  % Abscisa ceentral
  plot([xmed, xmed], [0, f(xmed)], 'k');
  % Etiquetas
  text(xmed-0.2,-0.2,'Xmed', 'fontsize', 20, 'fontweight', 'bold');
  text(xmed-0.2, 1.6, 'Ymed', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  
  hold off  
end

