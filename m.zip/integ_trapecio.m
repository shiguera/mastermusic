 
 function S= integ_trapecio(f,a,b,n)
  
   h = (b-a)/n;
  
   S=0;
   for i = 1:n
     xizq = a +(i-1)*h;
     xder = xizq + h;
     yizq = f(xizq);
     yder = f(xder);
     area_subintervalo = (yizq + yder)/2 * h;
     S = S + area_subintervalo;
   end
  
  
 end

 
 