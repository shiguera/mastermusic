function fig_trapecio()
  hold on
  
  % Función
  f = @(x) 3 + sin(x);
  a = pi/4;
  b = 5*pi/4;
  % Sombreado  
  % Hay que dibujar el sombreado lo primero para
  % que lo demás se dibuje encima y no quede tapado
  x = [a,b,b,a];
  y = [f(a),f(b),0,0];
  fill(x,y,[0.86, 0.86, 0.86]);
  % Figura base
  figura_base()
  %Etiquetas
  text(a-0.15, 1.6, 'Yizq', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  text(b+0.15, 1, 'Yder', 'fontsize', 20, 'rotation', 90, 'fontweight', 'bold');
  
  hold off  
end

